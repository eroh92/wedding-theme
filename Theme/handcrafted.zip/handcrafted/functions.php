<?php

// PROTECTION
if ( ! defined('ABSPATH') ) { die(''); }

/*
 * der|Design WordPress Framework 2.0.0
 * Designed & Developed by Ernesto Mendez
 */

include(TEMPLATEPATH . '/functions/core-functions.php');

der_initialize();

//$_GET['file'] = 'Forbidden';

?>